export class Music {
    id:number;
    name: string;
    url: string;
    artistName: string;
    imageUrl: string;
}
