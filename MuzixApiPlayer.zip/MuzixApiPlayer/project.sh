cd accountmanager
source ./env-variable.sh
cd ..
cd muzixmanager
source ./env-variable.sh
cd ..

